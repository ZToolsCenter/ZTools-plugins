import{U as a,C as n}from"./mermaid.core-CAqkCmS1-BN3kyVVD.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
