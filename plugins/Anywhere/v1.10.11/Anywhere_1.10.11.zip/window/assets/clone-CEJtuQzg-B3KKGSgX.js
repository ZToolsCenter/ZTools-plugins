import{E as r}from"./ChatMessage-B211grQ_.js";var e=4;function a(o){return r(o,e)}export{a as c};
